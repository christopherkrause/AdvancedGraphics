Name: Christopher Krause
SID: 11407768
Email Address: christopher.krause1@gmail.com

Files submitted:
________________

superquad.html
superquad.js
matrix.js
earth.png
earthAvgTemp.png
earthInet.png
earthWind.png
europa.png
marsTemp.png
space.png
README.txt

Project Title
_____________

Super Quadric Surface
featuring The Last Frontier


Program description.
____________________

This program begins by drawing a simple wireframe superquadric mesh. Gauraud shading is used and utilizing
the provided quadric formulas the texture mapping is computed.
Utilizing most of my code from the super torodial and following some of the inclass examples for texture mapping 
the next step was choose an image and feature such as allowing the user to move the surface or animate. 
I chose to allow the user to move the shape(already had that coded) and tried to get a radio set up so the user could 
change the image. I eventually ran out of time and must submit what I have and chose a Nasa Maritan Tempurature Map. 

I may mess with the radio buttons and submit late but that depends on extra time. 

I had a Title for my webpage but thought the space background was way too cool. Please comment out the 
background image if you want to see the header and footer. I didnt have time to make sytle sheets to bring the text
to the front. Again I will work on it and submit late if I have the time. The space background is just rad. 

!!!!!UPDATE!!!!!
So I got the text to have a background with my novice css skills and added the buttons to toggle between 
different images. I kindof hacked the changeTexture function by calling init() everytime a button was
pressed. Its not ideal but it works for now. Very fun and interesting project. 

Building/Running provided code.
_______________________________________

Unzip the provided tarball. Load the folder to an IDE like Webstorm. Run the html file through a local host. 
